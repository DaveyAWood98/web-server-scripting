<html>
    <body>
        <?php
        $myFile=fopen("mydata.txt","r") or exit("Can’t open file!");
        fclose($myFile);
        ?>
    </body>
</html>